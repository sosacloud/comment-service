const puppeteer = require('puppeteer');
import faker from "faker";
const pageUrl = 'http://localhost:3001/';
let page;
let browser;
const width = 1280;
const height = 720;

const comment = faker.random.words();

beforeAll(async () => {
    browser = await puppeteer.launch({
        headless: false,
        slowMo: 80,
        args: [`--window-size=${width},${height}`]
    });
    page = await browser.newPage();
    await page.setViewport({ width, height });
});
afterAll(() => {
    browser.close();
});




describe('Post Comment', () => {
    test('Checking that jest works', () => {

    });
  });