module.exports = {
  presets: [
    '@vue/App', '@babel/preset-env'
  ]
}
