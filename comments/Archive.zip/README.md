# comments

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Run your tests
```
npm run test
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

Elastic Beanstalk
Get your service, your database and your proxy onto AWS

Updated to node v8.9.4 (npm v5.6.0)
use touch, mv and rm in terminal to modify files